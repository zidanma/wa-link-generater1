document.getElementById("waForm").addEventListener("submit", function (e) {
  e.preventDefault();
  const number = document.getElementById("number").value.trim();
  const message = document.getElementById("message").value.trim();
  const baseURL = "https://wa.me/";

  if (!number) {
    alert("Nomor tidak boleh kosong!");
    return;
  }

  const fullNumber = "62" + number;
  const encodedMsg = encodeURIComponent(message);
  const waLink = message
    ? `${baseURL}${fullNumber}?text=${encodedMsg}`
    : `${baseURL}${fullNumber}`;

  document.getElementById("waLink").href = waLink;
  document.getElementById("waLink").textContent = waLink;
  document.getElementById("result").style.display = "block";
});
